package com.example.trump;

public class KraTaxBands {

}

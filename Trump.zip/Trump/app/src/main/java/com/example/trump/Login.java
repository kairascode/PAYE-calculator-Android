package com.example.trump;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText grossPay,Insurance,nhif;
    TextView result;
    Button calculate,cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        grossPay=(EditText)findViewById(R.id.grossPay);
        Insurance=(EditText)findViewById(R.id.insurance);
        nhif=(EditText)findViewById(R.id.nhif);
        calculate=(Button)findViewById(R.id.calculate);
        cancel=(Button)findViewById(R.id.cancel);
        result=(TextView)findViewById(R.id.result);


        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double gross= Double.parseDouble(grossPay.getText().toString());
                double insur=Double.parseDouble(Insurance.getText().toString());
                double nhifs=Double.parseDouble(nhif.getText().toString());

              payeCalculator(gross,insur,nhifs);



            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                grossPay.setText("");
                Insurance.setText("");
                nhif.setText("");



            }
        });

    }

   private float payeCalculator(double gross,double insur,double nhifs){

        double workFigure=gross-insur-nhifs;
         double tax=0;
         double bal=0;

        if(workFigure<24000){

            result.setText(String.valueOf(tax));
        }
        else if(workFigure>24000){
            bal=workFigure-24000;

            if(bal<16667){
                tax=(24000*0.1)-2400;
                result.setText(String.valueOf(tax));
                return 0;
            }
            else if(bal>=16667){

                bal=bal-16667;

                if(bal<16667){
                    tax=(16667*.15)+2400+(bal*.2)-2400;

                    result.setText(String.valueOf(tax));

                    return 0;
                }else if(bal>=16667){
                    bal=bal-16667;

                    if(bal<16667){

                        tax=2400+(16667*.15)+(16667*.20)+(bal*.25)-2400;

                        result.setText(String.valueOf(tax));

                        return 0;
                    }else if(bal>57334){
                        tax=2400+(16667*.15)+(16667*.20)+(bal*.25)-2400;
                        result.setText(String.valueOf(tax));
                        return  0;
                    }
                }

            }



        }


        return 0;
   }
}
